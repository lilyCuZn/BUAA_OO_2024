public enum TokenType {
    NUM, X,
    MULTI, MINUS, EXP, PLUS,
    LP, RP, //左括号和右括号
}
