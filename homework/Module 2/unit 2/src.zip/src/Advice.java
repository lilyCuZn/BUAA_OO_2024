public enum Advice {
    OVER, MOVE, REVERSE, OPEN, WAIT, RESET
}
